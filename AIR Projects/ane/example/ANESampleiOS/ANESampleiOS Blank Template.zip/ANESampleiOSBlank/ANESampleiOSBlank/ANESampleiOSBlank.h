//
//  ANESampleiOSBlank.h
//  ANESampleiOSBlank
//
//  Created by Kaoru Kawashima on 10/9/13.
//  Copyright (c) 2013 Kaoru Kawashima. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ANESampleiOSBlank : NSObject

@end
