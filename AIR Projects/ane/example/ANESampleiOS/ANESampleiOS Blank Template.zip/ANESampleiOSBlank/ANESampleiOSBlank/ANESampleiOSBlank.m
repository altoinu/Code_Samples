//
//  ANESampleiOSBlank.m
//  ANESampleiOSBlank
//
//  Created by Kaoru Kawashima on 10/9/13.
//  Copyright (c) 2013 Kaoru Kawashima. All rights reserved.
//

#import "FlashRuntimeExtensions.h"

void ANETestExtensionContextInitializer(void* extData, const uint8_t* ctxType, FREContext context, uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet) {
    
    *numFunctionsToTest = 2;
    
    FRENamedFunction* func = (FRENamedFunction*) malloc(sizeof(FRENamedFunction) * *numFunctionsToTest);
    
    /*
    func[0].name = (const uint8_t*) "showAlertMessage";
    func[0].functionData = NULL;
    func[0].function = &showAlertMessage;
    
    func[1].name = (const uint8_t*) "showBrowser";
    func[1].functionData = NULL;
    func[1].function = &showBrowser;
    */
    
    *functionsToSet = func;
    
}

void ANETestExtensionContextFinalizer(FREContext context) {
    
    return;
    
}

void ANETestExtensionInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet) {
    
    *extDataToSet = NULL;
    *ctxInitializerToSet = &ANETestExtensionContextInitializer;
    *ctxFinalizerToSet = &ANETestExtensionContextFinalizer;
    
}

void ANETestExtensionFinalizer(void* extData) {
    
    return;
    
}
